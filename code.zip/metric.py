import torch
from torch import nn

class DryDayLoss(nn.Module):
    def __init__(self, eps):
        super(DryDayLoss, self).__init__()
        self.eps = eps

    def forward(self, output, target):
        output_thresh = torch.sigmoid(output-self.eps).mean()
        target_thresh = torch.sigmoid(target-self.eps).mean()
        return (output_thresh - target_thresh) ** 2
    
class MaximumPrecipLoss(nn.Module):
    def __init__(self):
        super(MaximumPrecipLoss, self).__init__()

    def forward(self, output, target):
        output = output.max()
        target = target.max()
        return (output - target) ** 2
    
class AverageRainfallLoss(nn.Module):
    def __init__(self, eps):
        self.eps = eps
        super(AverageRainfallLoss, self).__init__()

    def forward(self, output, target):
        output = output[output > self.eps].mean()
        target = target[target > self.eps].mean()
        return (output - target) ** 2
    
class RainfallVariance(nn.Module):
    def __init__(self, eps):
        self.eps = eps
        super(RainfallVariance, self).__init__()

    def forward(self, output, target):
        output = output[output > self.eps].var()
        target = target[target > self.eps].var()
        return (output - target) ** 2